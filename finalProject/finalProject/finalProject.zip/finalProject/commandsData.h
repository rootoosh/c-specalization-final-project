#ifndef commandD
#define commandD


//the num that represent the command is the index of that command in the commandTable
int f_getNumCommand(char commandStr[3]);


int f_getNumOperandsByCommandIndex(int command);

int f_matchCommandResidence(int command, int residenceMethod, int operandSerial);
#endif // !commandD