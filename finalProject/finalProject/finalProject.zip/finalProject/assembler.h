#ifndef assembler
#define assembler


#include <stdio.h>

void f_assembleFirstPass(FILE* inputFile);

#endif // !assembler