#ifndef outputFile
#define outputFile

void f_writeObFile(char* nameFile);
void f_writeENTFile();
void f_writeEXTFile();
void writeRelFile();

#endif // !outputFile

